package assembler;


import java.io.*;
import java.util.*;

class Symbol
{	
	int sno;
	String value;
	int addr;	
}
class Literal
{
	int sno;
	String value;
	int addr;
}
class Pool
{
	int value;
}
public class Pass2
{
	public static void main(String[] args)throws Exception
	{
		File file1 = new File("C:/Users/CO/workspace/Assembler/src/symbol_table.txt");
		
		BufferedReader br1 = new BufferedReader(new FileReader(file1));
   
		ArrayList<Symbol> sym_array = new ArrayList<Symbol>();
   
		String st;
		
		while ((st = br1.readLine()) != null)
		{
			StringTokenizer str=new StringTokenizer(st," ");
			while (str.hasMoreTokens())
			{
				Symbol obj=new Symbol();
				obj.sno = Integer.parseInt(str.nextToken());
				obj.value = str.nextToken();
				obj.addr = Integer.parseInt(str.nextToken());
								
				sym_array.add(obj);  //adding symbols to our arraylist
			}			
		}
		br1.close();
		
        File file2 = new File("C:/Users/CO/workspace/Assembler/src/literal_table.txt");
		
		BufferedReader br2 = new BufferedReader(new FileReader(file2));
   
		ArrayList<Literal> lit_array = new ArrayList<Literal>();
		
		while ((st = br2.readLine()) != null)
		{
			StringTokenizer str=new StringTokenizer(st," ");
			while (str.hasMoreTokens())
			{
				Literal obj=new Literal();
				obj.sno = Integer.parseInt(str.nextToken());
				obj.value = str.nextToken();
				obj.addr = Integer.parseInt(str.nextToken());
								
				lit_array.add(obj);  //adding literals to our arraylist
			}
			
		}
		br2.close();
		
        File file3 = new File("C:/Users/CO/workspace/Assembler/src/pool_table.txt");
		
		BufferedReader br3 = new BufferedReader(new FileReader(file3));
   
		ArrayList<Pool> pool_array = new ArrayList<Pool>();
		
		while ((st = br3.readLine()) != null)
		{
			StringTokenizer str=new StringTokenizer(st," #");
			while (str.hasMoreTokens())
			{
				Pool obj=new Pool();
				obj.value = Integer.parseInt(str.nextToken());								
				pool_array.add(obj);  //adding literals to our arraylist
			}
			
		}
		br3.close();
		
		File target = new File("C:/Users/CO/workspace/Assembler/src/target_code.txt");
		FileWriter fr = new FileWriter(target);
		
		//--------------------------------------------------------------------------------------
		
		ArrayList ic_tokens = new ArrayList();
		
		FileReader fileReader = new FileReader("C:/Users/CO/workspace/Assembler/src/intermediate_code.txt");   //to read from the file
		
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        
        String line;
        
        while((line = bufferedReader.readLine()) != null) 
        {
        	StringTokenizer str = new StringTokenizer(line," ,()");
        	
        	while (str.hasMoreTokens())  
			{
				ic_tokens.add(str.nextToken());  //adding tokens to our arraylist (ic_tokens)		
			}
			/*stringBuffer.append(st);
			stringBuffer.append("\n");*/
        }  
        
        Iterator itr = ic_tokens.iterator();
        System.out.println("Tokens:");
		while(itr.hasNext()) 
		{	
	         System.out.print(itr.next()+ "\n");
	    }
        //---------------------------------------------------------------------------------
        
		int check =0;
		int flag = 0;
		
        for(int i=0;i<ic_tokens.size();i++)  //loop to check and compare the read input and store it in corresponding files
		{
			String str=(String)ic_tokens.get(i);		
			
			if(str.equals("IS"))
			{
				System.out.println(str);	//add nothing in the target code
			}
			else if((str.equals("AREG")) || (str.equals("BREG")) || (str.equals("CREG")) || (str.equals("DREG")))
			{
				if(str.equals("AREG"))
				{
					fr.write(" 1");
				}
				if(str.equals("BREG"))
				{
					fr.write(" 2");
				}
				if(str.equals("CREG"))
				{
					fr.write(" 3");
				}
				if(str.equals("DREG"))
				{
					fr.write(" 4");
				}
			}
			else if(str.equals("L"))   //to check in literal table
			{
				int next_token = Integer.parseInt(ic_tokens.get(i+1).toString());
				
				int adr = lit_array.get(next_token-1).addr;
				
				fr.write(" "+adr);
				i++;  //to skip the srno of the literal table
			}
			else if((str.equals("A")) || (str.equals("B")) || (str.equals("NEXT")) || (str.equals("BACK")))   //to check if the token is a symbol
			{
				//System.out.println("RED");
				for(int y=0;y<sym_array.size();y++)
				{
					 if(sym_array.get(y).value.equals(str))
					 {
						 int address = sym_array.get(y).addr;
						 fr.write(" "+address);
					 }
				}
			}
			
			else
			{
				if(check == 0)   //for the first address
				{
					//System.out.println(i);
					fr.write(str);
					check++;
				}
			    else if((ic_tokens.get(i-1).equals("IS")))   //for the opcode field
				{
			    		fr.write(" +"+str);
				}
			    else if(str.equals("AD"))
			    {
			    	i++;  //to skip the opcode
			    	
			    	int check_opcode = Integer.parseInt(ic_tokens.get(i).toString());
			    	
			    	if(check_opcode == 05)
			    	{
			    		fr.write("   "+ic_tokens.get(i+1).toString());
			    	}
			    }
			    else if(str.equals("DL"))
			    {
			    	i++;  //to skip the opcode
			    	
			    	int check_opcode = Integer.parseInt(ic_tokens.get(i).toString());
			    	
			    	   //because one literal must be processed only once
			    	
			    	if(check_opcode == 02)
			    	{
			    		fr.write("   "+ic_tokens.get(i+1).toString());
			    		flag++;
			    	}
			    	
			    }
			    else if(i != ic_tokens.size()-1)  //to check for the index out of bound
				{
					 if((ic_tokens.get(i+1).equals("IS")) || (ic_tokens.get(i+1).equals("AD")) || (ic_tokens.get(i+1).equals("DL"))) //for the address like 200 etc
						{
					    	fr.write("\n"+str);	//for the location counter ie address
						}
				}
				
			}
		}
        
            //--------------- Always close files.
        fr.close();
        bufferedReader.close(); 
	}	
}