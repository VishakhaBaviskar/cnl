package Macro_new;

import java.io.*;
import java.util.ArrayList;
import java.util.StringTokenizer;

class data{

	String arr[];
}

class evtab{

	int val=0;
	
}

class mntc{
	String val;
	int seq;
	int pp,kp,ev,mdtp,kpdtp,sstp;
}

public class Code4 {
	static int count=0;
	public static void main(String args[])throws Exception
	{
		File input=new File("MacroCall.txt");
		BufferedReader br=new BufferedReader(new FileReader(input));
		String str1;
		ArrayList<String> tokens=new ArrayList<String> ();

		
		//--------------------------------------------------DECLARATIONS--------------------------------
		ArrayList<Integer>ssnlist=new ArrayList<Integer>();
	

		File ssn=new File("ss.txt");
		BufferedReader br0=new BufferedReader(new FileReader(ssn));
	while((str1=br0.readLine())!=null)
	{
		StringTokenizer st=new StringTokenizer(str1," ");
		st.nextToken();
		ssnlist.add(Integer.parseInt(st.nextToken()));
		
	}
	br0.close();
		ArrayList<data>aplist=new ArrayList<data>();
		ArrayList<evtab>evlist=new ArrayList<evtab>();
		ArrayList<mntc>mntlist=new ArrayList<mntc>();
		ArrayList<String>mdtarr=new ArrayList<String>();
		RandomAccessFile mdt=new RandomAccessFile("mdt.txt","rw");
		while((str1=mdt.readLine())!=null)
		{
			mdtarr.add(str1);
		}
		File mnt1=new File("MacroExp.txt");
		
		if(mnt1.exists()){
			mnt1.delete();
		}
		File output=new File("MacroExp.txt");
		FileWriter fw=new FileWriter(output);
		File mnt=new File("mnt.txt");

		BufferedReader br1=new BufferedReader(new FileReader(mnt));

		int cntr=0,cc=0,flag=0;
		while((str1=br1.readLine())!=null){
			StringTokenizer st=new StringTokenizer(str1," ");
			while(st.hasMoreTokens()){
				mntc m=new mntc();
				m.seq=Integer.parseInt(st.nextToken());
				m.val=st.nextToken();
				m.pp=Integer.parseInt(st.nextToken());
				m.kp=Integer.parseInt(st.nextToken());
				m.ev=Integer.parseInt(st.nextToken());
				int h=Integer.parseInt(st.nextToken());
				m.mdtp=h;
				if(flag==0)
				{
					count=h;
					flag=1;
				}
				m.kpdtp=Integer.parseInt(st.nextToken());
				m.sstp=Integer.parseInt(st.nextToken());
				mntlist.add(m);
				cntr=cntr+m.pp+m.kp;
				cc++;
			}
			
		}
		
		br1.close();
	
		File kp=new File("kp.txt");	
		ArrayList<String>kpd=new ArrayList<String>();
		BufferedReader br2=new BufferedReader(new FileReader(kp));
		
		while((str1=br2.readLine())!=null){
			StringTokenizer st=new StringTokenizer(str1," ");
			while(st.hasMoreTokens()){
				st.nextToken();
				st.nextToken();
				kpd.add(st.nextToken());
			}
			
		}
		br2.close();
		
		
	
		//--------------------------------------------------LOOP----------------------------------------
	
	
		String array[]=new String[cntr];
		
		int mec=0,ppcnt=0,kpcnt=0;
		StringTokenizer st;
		String str=new String();
		while((str=br.readLine())!=null)
		{
		
			flag=0;
			st=new StringTokenizer(str," ,");
			str1=st.nextToken();
			for(int j=0;j<mntlist.size();j++)
			{
				if(str1.equals(mntlist.get(j).val))
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				fw.write(str+'\n');
			}
			else
			{
				cntr=0;
				for(int j=0;j<mntlist.size();j++)
				{
					if(str1.equals(mntlist.get(j).val))
					{
						 mec=mntlist.get(j).mdtp;
						 ppcnt=mntlist.get(j).pp;
						 kpcnt=mntlist.get(j).kp;
						
						 break;
					}
					cntr=mntlist.get(j).pp+mntlist.get(j).kp+cntr;
				}
						
				data d=new data();
				d.arr=new String [ppcnt+kpcnt];
				for(int y=0;y<ppcnt;y++)
				{
					d.arr[y]=st.nextToken().toString();
					array[cntr++]=d.arr[y];
				
				}
				
				for(int y=0;y<kpcnt;y++)
				{
					d.arr[y+ppcnt]=kpd.toString();
					array[cntr++]=d.arr[y+ppcnt];
				}
				aplist.add(d);
				str=mdtarr.get(mec-count);
			
			//--------------------------while for macro exp---------------------

				while(!str.contains("MEND"))            //str=line read
			{
				
				st=new StringTokenizer(str," ");
				st.nextToken();                      //mec value
				String s=st.nextToken().toString();  //s contains value after mec
				
				if(str.contains("LCL"))
				{
					StringTokenizer temp=new StringTokenizer(st.nextToken(),"(),");
				evtab ev=new evtab();
					evlist.add(ev);
					mec++;
					str=mdtarr.get(mec-count);
				}
				else if(str.contains("SET"))
				{
					
					st=new StringTokenizer(str," ");
					st.nextToken();
					String temp=st.nextToken();
					st.nextToken();
					String val=st.nextToken().toString();      // token after SET
					
					int add=0;
					if(!val.contains("+"))
							{
						add=Integer.parseInt(val);
						System.out.println(add);
						
							}
					else
					{
						
						StringTokenizer tem1=new StringTokenizer(val,"(,)+");
						tem1.nextToken();
						int p=Integer.parseInt(tem1.nextToken().toString());
						p--;
						for(int i=0;i<evlist.size();i++)
						{
							if(i==p)
							{
								p=evlist.get(i).val;								
							}
						}						
						int q=Integer.parseInt(tem1.nextToken().toString());
						System.out.println(q);
						add=p+q;
						
					}
					
					StringTokenizer temp1=new StringTokenizer(temp,"(,)");
					String ev=temp1.nextToken().toString();
					int pos=Integer.parseInt(temp1.nextToken().toString());
					pos--;				
					
					for(int i=0;i<evlist.size();i++)
					{
						if(i==pos)						{
							evlist.get(i).val=add;
					}
					}
					mec++;
					str=mdtarr.get(mec-count);
				}
				else if(str.contains("MOVER")||(str.contains("MOVEM"))||(str.contains("MULT")))
				{
					st=new StringTokenizer(str," ");
					st.nextToken();
					if(str.contains("="))
					{						
						String one=st.nextToken().toString(); //MOVER
						String two=st.nextToken().toString(); //(P,1),='0'
						st=new StringTokenizer(two,"(),");
				st.nextToken();
			
						int three=Integer.parseInt(st.nextToken().toString());
						three--;
						
						String four=array[three];  //AREG
						String five=st.nextToken();   //='0'
						fw.write("+"+one+" "+four+","+five+'\n');
					}
					
					else if(str.contains("+"))
					{
						String one=st.nextToken().toString(); //MOVEM
				
						StringTokenizer two=new StringTokenizer(st.nextToken().toString(),"(),+"); //(P,3),(P,1)+(E,1)
					two.nextToken();
			
						int three=Integer.parseInt(two.nextToken().toString()); //3
						three--;
						
						String four=array[three];  //AREG
						two.nextToken();
						int oone=Integer.parseInt(two.nextToken().toString()); //1
						oone--;
						String five=array[oone];  //A
						two.nextToken();
				
						int six=Integer.parseInt(two.nextToken().toString());   //1
						six--;
					
						int y=evlist.get(six).val;
						fw.write("+"+one+" "+four+","+five+"+"+six+'\n');
					
					}					
					else
					{
						String one=st.nextToken().toString(); //MOVEM or MULT
						String two=st.nextToken().toString(); //AREG
						StringTokenizer three=new StringTokenizer(st.nextToken(),"(),");  //(P,4)
						three.nextToken();
						int y=Integer.parseInt(three.nextToken().toString());
						y--;
					
						String five=array[y];  //A
						fw.write("+"+one+" "+two+","+five+'\n');						
					}
					mec++;
					str=mdtarr.get(mec-count);
				}
				
				else if((str.contains("AIF"))||(str.contains("AGO")))
				{
					st=new StringTokenizer(str," ");
					st.nextToken();
					st.nextToken();   //AIF
					StringTokenizer temp=new StringTokenizer(st.nextToken(),"(),"); //E 1
				
					temp.nextToken();
					int y=Integer.parseInt(temp.nextToken());
					y--;
					int a=evlist.get(y).val;
					st.nextToken();
					temp=new StringTokenizer(st.nextToken(),"(),");
					temp.nextToken();
					y=Integer.parseInt(temp.nextToken());
					y--;
					int b=Integer.parseInt(array[y]);

					temp=new StringTokenizer(st.nextToken(),"(),");
					temp.nextToken();
					y=Integer.parseInt(temp.nextToken());
					y--;
					int q=ssnlist.get(y);
					
					if(a!=b)
					{
						mec=q;
					}
					else
					{
						mec++;
					}
					str=mdtarr.get(mec-count);
					
				}
			}
			}
		}
		br.close();
		fw.close();
		mdt.close();
	}

}