package Macro_new;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class pass1 {
	static String[] macro_str;
	static String edit;
	static FileOutputStream temp;
	static int macrocnt=0;
	static int flag=0;
	static int noofmacro=0;

	static String[][] MNT1=new String[2][7];
	
	
	static ArrayList<String> PNT=new ArrayList<String>();
	static int PNTcntr;
	static int PP=0;
	
	static ArrayList<String> KPDT=new ArrayList<String>();
	static int KPDTcnt=0;
	static int KP=0;
	
	static ArrayList<String> MDT=new ArrayList<String>();
	static int MDTcnt=0;
	static int MDTP=0;
	
	static ArrayList<String> EVNT=new ArrayList<String>();
	static int EVNTcnt=0;
	static int EV=0;
	
	static ArrayList<String> EVT=new ArrayList<String>();
	
	static ArrayList<String> SSNT=new ArrayList<String>();
	static int SSNTcnt=0;
	
	static ArrayList<String> SST=new ArrayList<String>();
	
	
	public static void main(String[] args) throws IOException 
	{
		//initialization of MNT
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<7;j++)
			{
				MNT1[i][j]="0";
			}
		}
		
		temp=new FileOutputStream("temp.txt");
		FileInputStream f_macro=new FileInputStream("Macro_input.txt");
		String macrofile=new String("");
		int k;
		while((k=f_macro.read())!=-1)
		{
			macrofile=macrofile+(char)k;
		}
		StringTokenizer st = new StringTokenizer(macrofile,",\n");
		int c=0;
		String str1;
		while (st.hasMoreTokens()) 
		{  
			//System.out.println(st.nextToken());
			str1=st.nextToken().toString();
			//System.out.println(str1);
			byte[] b1 = str1.getBytes();
			temp.write(b1);
			temp.write(10);	
		}
		FileInputStream fin=new FileInputStream("temp.txt");
		String datainfile=new String("");
		int l;
		while((l=fin.read())!=-1)
		{
			datainfile=datainfile+(char)l;
		}
		macro_str = datainfile.split("\\s");
		System.out.println("Input file: ");
		for(int i=0;i<macro_str.length;i++)
		{
			System.out.println(macro_str[i]);
		}
		
		
		
		while(macrocnt<macro_str.length)//loop till the end of macro_str ie i/p
		{
			PP=0;//no of positional parameters
			KP=0;//no of keyword parameters
			EV=0;//no of expansion time variables
			flag=0;//it is used to see if the MDTP is written in MNT or not
			while(!macro_str[macrocnt].equals("MEND"))//loop till the end of one macro
			{
				
				if(macro_str[macrocnt].startsWith("&"))//case for set
				{
					if(flag==0)//inc MDTP and add it to MNT if not added earlier
					{
						MDTP++;
						MNT1[noofmacro][4]=Integer.toString(MDTP);
						flag=1;//flag is set to
					}
					else//if MDTP is added earlier then only inc it
					{
					MDTP++;
					}
					MDT.add(Integer.toString(MDTP));//MDTP is added to MDT
					
					edit=delete_start(macro_str[macrocnt]);//to delete &
					String esq=get_ev_seqno(edit);//to get seq no of the ev
					String st1="";
					if(esq!=null)//generate a string to add it to MDT
					{
						st1=st1+"(E,"+esq+")";
					}
					MDT.add(st1);//add the created string to mdt
					
					macrocnt++;//point to next
					MDT.add(macro_str[macrocnt]);//pnts to set so directly add it to MDT
					macrocnt++;//ponts to value
					
					if(macro_str[macrocnt].startsWith("&"))
					{
						String st11=delete_start(macro_str[macrocnt]);
						String name1="";//name of the paramter
						String st111="";
						int pluspos=0;
						for(int i=0;i<st11.length();i++)//stops at plus pos
						{
							if(st11.charAt(i)=='+')
							{
								pluspos=i;//pos of plus is stored
								break;
							}
							name1=name1+st11.charAt(i);
						}
						
						String sq1=get_ev_seqno(name1);//seq no of ev is taken
						String add="";//add value is calculated
						for(int i=pluspos+1;i<st11.length();i++)
						{
							add=add+st11.charAt(i);
						}
						
						int v2=Integer.parseInt(add);
						int pos=find_pos_evt(sq1);
						pos=pos+1;
						String v1_str=EVT.get(pos);
						int v1=Integer.parseInt(v1_str);
						v1=v1+v2;//these values are added
						EVT.set(pos, Integer.toString(v1));//updated in EVT
						String xyz="(E,"+sq1+")+"+add;//formatted string created to add into MDT
						MDT.add(xyz);//MDT entry is added
					}
					else//if it is only a number not addition
					{
						int pos=find_pos_evt(esq);//find seq no of ev
						pos=pos+1;//pos + 1 stores its actual value
						EVT.set(pos,macro_str[macrocnt]);//update the value
						MDT.add(macro_str[macrocnt]);//add the value to MDT
					}
					
					MDT.add("  ");
				}
				else if(macro_str[macrocnt].startsWith("."))//it is a ss
				{
					edit=delete_start(macro_str[macrocnt]);//delete .
					SSNTcnt++;//seq no in SSNT
					SSNT.add(Integer.toString(SSNTcnt));//add it to SSNT
					SSNT.add(edit);//add the name of ss
					SST.add(Integer.toString(SSNTcnt));//add the same sq no in SST
					MDTP++;
					SST.add(Integer.toString(MDTP));//the corresponding MDTP is added where SS is detected
					MDTP--;
					MNT1[noofmacro][6]=Integer.toString(SSNTcnt);//SSNTP is added in MDT
					macrocnt++;
					//if mnemonic call process_mnemonic
					if(macro_str[macrocnt].equals("MOVER")||macro_str[macrocnt].equals("MULT")||macro_str[macrocnt].equals("MOVEM"))
					{
					process_mnemonic();
					}
					
				}
				else//detects tab
				{
					macrocnt++;//points to instruction
					if(macro_str[macrocnt].equals("MACRO"))
					{
						macrocnt=macrocnt+2;//to go directly to macro name
						MNT1[noofmacro][0]=macro_str[macrocnt];//added it to MNT
						
						macrocnt++;//to point to parameters
						while(macro_str[macrocnt].startsWith("&"))//loop till end of all the parameters
						{
							if(macro_str[macrocnt].contains("="))//then it is a keyword para
							{
								edit=get_para_name(macro_str[macrocnt]);//the name between & and = is returned
								PNTcntr++;//sq no in PNT is incremented
								PNT.add(Integer.toString(PNTcntr));//add it to PNT table
								PNT.add(edit);//add name of the para
								KPDTcnt++;//sq no in KPDT is inc
								KP++;//no of keyword parameters are incremented
								KPDT.add(Integer.toString(KPDTcnt));//add count
								KPDT.add(edit);//add name of KP
								edit=get_default_val(macro_str[macrocnt]);//add default value(function returns a string without &)
								KPDT.add(edit);//add default value to KPDT
								MNT1[noofmacro][5]=Integer.toString(KPDTcnt);//add KPDTP in MNT
							}
							else//if positional para
							{
								edit=delete_start(macro_str[macrocnt]);//delete &
								PNTcntr++;//sq no in PNT is incremented
								PP++;//no of positional parameters are incremented
								PNT.add(Integer.toString(PNTcntr));//add seq no
								PNT.add(edit);//add name to PNT
							}
							macrocnt++;//it is incremented here because we have to check if the next string from macro_str is a parameter or not
						}
						macrocnt--;//if it is not a para then it comes out of the loop so we are decrementing it beacuse at end of while there is inc
						
						
						MNT1[noofmacro][1]=Integer.toString(PP);//added to MNT
						MNT1[noofmacro][2]=Integer.toString(KP);
						
					}
					if(macro_str[macrocnt].equals("MEND"))
					{
						MDTP++;
						MDT.add(Integer.toString(MDTP));
						MDT.add("  ");
						MDT.add(macro_str[macrocnt]);
						MDT.add("  ");
						MDT.add("  ");
						macrocnt++;
						
						MNT1[noofmacro][3]=Integer.toString(EV);
						break;
						
					}
					if(macro_str[macrocnt].equals("MOVER")||macro_str[macrocnt].equals("MULT")||macro_str[macrocnt].equals("MOVEM"))
					{
						//if it is a mnemonic
						process_mnemonic();//function processes any mnemonic
					}
					if(macro_str[macrocnt].equals("LCL"))
					{
						if(flag==0)//MDTP is incremented
						{
							MDTP++;
							MNT1[noofmacro][4]=Integer.toString(MDTP);
							flag=1;
						}
						else
						{
						MDTP++;
						}
						MDT.add(Integer.toString(MDTP));//1
						MDT.add("  ");
						MDT.add(macro_str[macrocnt]);//LCL is added
						macrocnt++;//points to the ev
						EVNTcnt++;//seq no of EVNT is inc
						EV++;//ev cntr is inc
						EVNT.add(Integer.toString(EVNTcnt));//cntr is added to EVNT and EVT
						EVT.add(Integer.toString(EVNTcnt));
						EVT.add(Integer.toString(-1));//the value is added in front of seq no
						edit=delete_start(macro_str[macrocnt]);//delete &
						EVNT.add(edit);//add the ev name to EVNT
						String esq=get_ev_seqno(edit);//get the seq no from the tab to add it to MDT
						String st1="";
						if(esq!=null)//create a formatted string to add it to MDT
						{
							st1=st1+"(E,"+esq+")";
						}
						MDT.add(st1);//add the formatted string to MDT
						MDT.add("  ");
					}
					if(macro_str[macrocnt].equals("AIF"))
					{
						if(flag==0)
						{
							MDTP++;
							
							MNT1[noofmacro][4]=Integer.toString(MDTP);
							flag=1;
						}
						else
						{
						MDTP++;
						}
						MDT.add(Integer.toString(MDTP));//add MDTP in MDT
						MDT.add("  ");
						MDT.add(macro_str[macrocnt]);//add AIF
						macrocnt++;
						String s1="";//extract first string
						for(int i=2;i<macro_str[macrocnt].length();i++)
						{
							s1=s1+macro_str[macrocnt].charAt(i);
						}
						String st1="";
						String sq1=get_para_seqno(s1);//get seq no if it is a para
						if(sq1!=null)
						{
							st1=st1+"((P,"+sq1+") ";
						}
						else
						{
							sq1=get_ev_seqno(s1);//get seq no if it is an ev
							if(sq1!=null)
							{
								st1=st1+"((E,"+sq1+") ";
							}
						}
						macrocnt++;
						st1=st1+macro_str[macrocnt];//ad ne eq etc
						macrocnt++;
						
						String s2="";//extract second string
						for(int i=1;i<macro_str[macrocnt].length();i++)
						{
							if(macro_str[macrocnt].charAt(i)==')')
							{
								break;
							}
							s2=s2+macro_str[macrocnt].charAt(i);
						}
						String sq2=get_para_seqno(s2);//get seq no if it is a para
						if(sq2!=null)
						{
							st1=st1+" (P,"+sq2+"))";
						}
						else
						{
							sq2=get_ev_seqno(s2);//get seq no if it is an ev
							if(sq2!=null)
							{
								st1=st1+" (E,"+sq2+"))";
							}
						}
						MDT.add(st1);//add formatted string to MDT
						macrocnt++;
						edit=delete_start(macro_str[macrocnt]);//delete .
						String sq3=get_ss_seqno(edit);//get seq no no of ss
						st1="";
						st1=st1+"(S,"+sq3+")";//create a formatted string
						MDT.add(st1);//add it to MDT
					}
				}
				
				macrocnt++;//while loop incre
			}
			noofmacro++;//inc no of macros
		}
		
		

		
		
		
		System.out.println("\n**********MNT1**********\n");
		System.out.println("Macro Name\t#PP\t#KP\t#EV\tMDTP\tKPDT\tSSTP");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<7;j++)
			{
				System.out.print(MNT1[i][j]+"\t");
			}
			System.out.print("\n");
		}
		System.out.println("\n**********PNT**********\n");
		
		for(int i=0;i<PNT.size();i=i+2)
		{
			System.out.print(PNT.get(i));
			System.out.print("\t");
			System.out.print(PNT.get(i+1));
			System.out.print("\n");
		}
		
	System.out.println("\n**********EVNT**********\n");
		
		for(int i=0;i<EVNT.size();i=i+2)
		{
			System.out.print(EVNT.get(i));
			System.out.print("\t");
			System.out.print(EVNT.get(i+1));
			System.out.print("\n");
		}
		
	System.out.println("\n**********EVT**********\n");
		
		for(int i=0;i<EVT.size();i=i+2)
		{
			System.out.print(EVT.get(i));
			System.out.print("\t");
			System.out.print(EVT.get(i+1));
			System.out.print("\n");
		}
		
		
	System.out.println("\n**********SSNT**********\n");
		
		for(int i=0;i<SSNT.size();i=i+2)
		{
			System.out.print(SSNT.get(i));
			System.out.print("\t");
			System.out.print(SSNT.get(i+1));
			System.out.print("\n");
		}
		
	System.out.println("\n**********SST**********\n");
		
		for(int i=0;i<SST.size();i=i+2)
		{
			System.out.print(SST.get(i));
			System.out.print("\t");
			System.out.print(SST.get(i+1));
			System.out.print("\n");
		}
		
		
		System.out.println("\n**********KPDT**********\n");
		
		for(int i=0;i<KPDT.size();i=i+3)
		{
			System.out.print(KPDT.get(i));
			System.out.print("\t");
			System.out.print(KPDT.get(i+1));
			System.out.print("\t");
			System.out.print(KPDT.get(i+2));
			System.out.print("\n");
		}
		
		
		
		System.out.println("\n**********MDT**********\n");
		
		for(int i=0;i<MDT.size();i=i+5)
		{
			System.out.print(MDT.get(i));
			System.out.print("\t");
			System.out.print(MDT.get(i+1));
			System.out.print("\t");
			System.out.print(MDT.get(i+2));
			System.out.print("\t");
			System.out.print(MDT.get(i+3));
			System.out.print("\t");
			System.out.print(MDT.get(i+4));
			
			System.out.print("\n");
		}
	}
	public static String delete_start(String str) {
		String str1="";
		for(int i=1;i<str.length();i++)
		{
			str1=str1+str.charAt(i);
		}
		return str1;
	}
	public static String get_para_name(String str) {
		String str1="";
		int i=1;
		while(str.charAt(i)!='=')
		{
			str1=str1+str.charAt(i);
			i++;
		}
		return str1;
	}
	public static String get_default_val(String str) {
		int pos=0;
		for(int i=1;i<str.length();i++)
		{
			if(str.charAt(i)=='=')
			{
				pos=i;
				break;
			}
		}
		String str1="";
		for(int i=pos+1;i<str.length();i++)
		{
			str1=str1+str.charAt(i);
		}
		return str1;
	}
	public static void process_mnemonic()
	{
		
		if(flag==0)
		{
			MDTP++;
			MNT1[noofmacro][4]=Integer.toString(MDTP);
			flag=1;
		}
		else
		{
		MDTP++;
	
		}
		MDT.add(Integer.toString(MDTP));//add to MDT
		MDT.add("  ");
		MDT.add(macro_str[macrocnt]);//add mnemonic name
		
		macrocnt++;
		//if it is a reg
		if(macro_str[macrocnt].equals("AREG") ||macro_str[macrocnt].equals("BREG")||macro_str[macrocnt].equals("CREG")||macro_str[macrocnt].equals("DREG"))
		{
			MDT.add(macro_str[macrocnt]);
		}
		else if(macro_str[macrocnt].startsWith("&"))//if it is a parameter
		{
			edit=delete_start(macro_str[macrocnt]);//delet &
			String seqno=get_para_seqno(edit);//find sq no from para table
			if(seqno.equals(null))
			{
				System.out.println("null");
			}
			else//create formatted string
			{
				String st="(P,"+seqno+")";
				MDT.add(st);//add it to MDT
			}
		}
		macrocnt++;//second operand

		if(macro_str[macrocnt].startsWith("="))//if it is a literal
		{
			MDT.add(macro_str[macrocnt]);
		}
		else if(macro_str[macrocnt].startsWith("&"))//if it is a paramter
		{
			if(macro_str[macrocnt].contains("+"))//if it contains plus find out para,search for seq no in all the tables
			{
					String st=delete_start(macro_str[macrocnt]);
					String name1="";
					String st1="";
					int pluspos=0;
					for(int i=0;i<st.length();i++)
					{
						if(st.charAt(i)=='+')
						{
							pluspos=i;
							break;
						}
						name1=name1+st.charAt(i);
					}
					
					String sq1=get_para_seqno(name1);//if a para
					if(sq1!=null)
					{
						st1=st1+"(P,"+sq1+")+";
					}
					else
					{
						sq1=get_ev_seqno(name1);//if an ev
						if(sq1!=null)
						{
							st1=st1+"(E,"+sq1+")+";
						}
						//generate corresponding formatted strings
					}
					//same for the variable after 
					String name2="";
					for(int i=pluspos+2;i<st.length();i++)
					{
						name2=name2+st.charAt(i);
					}
					
					String sq2=get_para_seqno(name2);
					if(sq2!=null)
					{
						st1=st1+"(P,"+sq2+")";
					}
					else
					{
						sq2=get_ev_seqno(name2);
						if(sq2!=null)
						{
							st1=st1+"(E,"+sq2+")";
						}
					}
					MDT.add(st1);
			}
			else//if not plus then its only para so process only one para
			{
				edit=delete_start(macro_str[macrocnt]);
				String seqno=get_para_seqno(edit);
				if(seqno.equals(null))
				{
					System.out.println("null");
				}
				else
				{
					String st="(P,"+seqno+")";
					MDT.add(st);
				}
			}
		}
	}
	
	public static String get_para_seqno(String str) 
	{
		String seqno="";
		for(int i=1;i<PNT.size();i=i+2)
		{
			if(PNT.get(i).equals(str))
			{
				seqno=PNT.get(i-1);
				break;
			}
		}
		if(seqno.equals(""))
		{
		 return null;	
		}
		else
		{
		 return seqno;
		}
	}
	
	public static String get_ev_seqno(String str) 
	{
		String seqno="";
		for(int i=1;i<EVNT.size();i=i+2)
		{
			if(EVNT.get(i).equals(str))
			{
				seqno=EVNT.get(i-1);
				break;
			}
		}
		
		if(seqno.equals(""))
		{
		 return null;	
		}
		else
		{
		 return seqno;
		}
	}
	
	
	
	public static String get_ss_seqno(String str) 
	{
		String seqno="";
		for(int i=1;i<SSNT.size();i=i+2)
		{
			if(SSNT.get(i).equals(str))
			{
				seqno=SSNT.get(i-1);
				break;
			}
		}
		
		if(seqno.equals(""))
		{
		 return null;	
		}
		else
		{
		 return seqno;
		}
	}
	public static int find_pos_evt(String esq) {
		int pos=-1;
		for(int i=0;i<EVT.size();i=i+2)
		{
			if(EVT.get(i).equals(esq))
			{
				pos=i;
				break;
			}
		}
		return pos;
	}

}
