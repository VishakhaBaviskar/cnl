package scheduling;

import java.util.Scanner;

class fcfs
{
    int wait;
    int submission;
    int bursts;
	int turnAround;//completion time-arrival time
	int completionTime = 0;
    fcfs(int sub,int bur)
    {
        submission = sub;
        bursts = bur;
    }

}
class Processmain
{
    private static Scanner s;
    static int  avgwaitingtime=0;
	static int avgcompletiontime=0;
	public static void main(String[] args)
	{
        int x=0;
		s = new Scanner(System.in);
		System.out.println("Enter the number of processes:");
		int n = s.nextInt();
        fcfs[] myProcess = new fcfs[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter Arrival time and bursts: ");
			int sub  = s.nextInt();
			int bur = s.nextInt();
			myProcess[i] = new fcfs(sub,bur);
		}
        for(int i=0;i<myProcess.length;i++)
        {
            x = x+myProcess[i].bursts;
			myProcess[i].completionTime = x;
			myProcess[i].turnAround = myProcess[i].completionTime - myProcess[i].submission;
			myProcess[i].wait = myProcess[i].turnAround - myProcess[i].bursts;
			System.out.println("Process "+i+":");
			System.out.println("Turnaround\tCompletion\twaiting");
			System.out.println(myProcess[i].turnAround+"\t\t\t"+myProcess[i].completionTime+"\t\t\t"+myProcess[i].wait);
			avgwaitingtime = avgwaitingtime + myProcess[i].wait;
			avgcompletiontime = avgcompletiontime + myProcess[i].completionTime;
        }
        System.out.println("average waiting time : "+avgwaitingtime/myProcess.length);
        System.out.println("average completion time : "+avgcompletiontime/myProcess.length);
    }
}
/*output : 
	Enter the number of processes:
		3
		Enter Arrival time and bursts: 
		0 24
		Enter Arrival time and bursts: 
		0 3
		Enter Arrival time and bursts: 
		0 3
		Process 0:
		Turnaround	Completion	waiting
		24			24			0
		Process 1:
		Turnaround	Completion	waiting
		27			27			24
		Process 2:
		Turnaround	Completion	waiting
		30			30			27
		average waiting time : 17
		average completion time : 27
*/