int a,b;
String a,b,c;
