public class Jp
{
public static void main(String []args)
{
int a,b;
a=a+b;
System.out.println("\n \t Good Morning \n");
}
}
