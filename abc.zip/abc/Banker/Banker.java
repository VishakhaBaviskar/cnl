package practice;

import java.util.Scanner;

public class Banker 
{
	public static void main(String[] args) 
	{
		int n,m,ans=1;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter number of processs");
		n=sc.nextInt();
		System.out.println("Enter no of resource");
		m=sc.nextInt();
		int[] a=new int[m];
		int[] ax1=new int[m];
		int[] total=new int[m];
		System.out.println("Enter max instance of resourses");
		for(int i=0;i<m;i++)
		{
			ax1[i]=sc.nextInt();
		}
		/*System.out.println("Enter available resorces");
		for(int i=0;i<m;i++)
		{
			a[i]=sc.nextInt();
		}*/
		System.out.println("Enter allocaltion of resoures");
		int[][] al=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				System.out.println("Enter allocation of resorces of resource "+j+"for process "+i);
				al[i][j]=sc.nextInt();
				total[j]=total[j]+al[i][j];

			}
		}
		System.out.println("total allocated resourses");
		for(int i=0;i<m;i++)
		{
			System.out.println(total[i]);
		}
		System.out.println("available resourses");
		for(int i=0;i<m;i++)
		{
			a[i]=ax1[i]-total[i];
			System.out.println(a[i]);
		}
		System.out.println("Enter maximum of resoures");
		int[][] max=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				System.out.println("Enter maximum of resorces of resource "+j+"for process "+i);
				max[i][j]=sc.nextInt();
			}
		}
		int need[][]=new int[n][m];
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				need[i][j]=max[i][j]-al[i][j];
			}
		}
		System.out.println("Allocated resourese");
		for(int i=0;i<n;i++)
		{
			System.out.print("\n");
			for(int j=0;j<m;j++)
			{
				System.out.print(al[i][j]);
				System.out.print("\t");
			}
		}
		System.out.println("maximum resourese");
		for(int i=0;i<n;i++)
		{
			System.out.print("\n");
			for(int j=0;j<m;j++)
			{
				System.out.print(max[i][j]);
				System.out.print("\t");
			}
		}
		System.out.println("need resourese");
		for(int i=0;i<n;i++)
		{
			System.out.print("\n");
			for(int j=0;j<m;j++)
			{
				System.out.print(need[i][j]);
				System.out.print("\t");
			}
		}
		if(safety(a,al,need,n,m))
		{
			System.out.println("Safe sequence");
			System.out.println("Safe sequence is as follows : ");
			for(int i=0;i<n;i++)
			{
				System.out.println(safe[i]);
			}
		}
		else
		{
			System.out.println("System in unsafe state");
		}
		do{
		System.out.println("do u want to request");
		int pid=sc.nextInt();
		int req[]=new int[m];
		for(int i=0;i<m;i++)
		{
			req[i]=sc.nextInt();
		}
		if(requFreq(a,al,need,req,n,m,pid))
		{
			for(int i=0;i<m;i++)
			{
				a[i]=a[i]-req[i];
				need[pid][i]=need[pid][i]-req[i];
				al[pid][i]=al[pid][i]+req[i];	
			}
			if(safety(a,al,need,n,m))
			{
				System.out.println("Safe sequence");
				System.out.println("Safe sequence is as follows : ");
				for(int i=0;i<n;i++)
				{
					System.out.println(safe[i]);
				}
			}
			else
			{
				System.out.println("System in unsafe state");
			}
		}
		System.out.println("Continue request[1/0]");
		ans=sc.nextInt();
		}while(ans==1);
	}
	static int safe[]=new int[20];
	static boolean safety(int a[],int al[][],int need[][],int n1,int m1)
	{
		int n=n1;int m=m1;
		int avail[]=new int[m];
		int allo[][]=new int[n][m];
		int nee[][]=new int[n][m];
		for(int i=0;i<m;i++)
		{
			avail[i]=a[i];
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				allo[i][j]=al[i][j];
				
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				nee[i][j]=need[i][j];
				
			}
		}
		boolean fin[]=new boolean[n];
		for(int i=0;i<n;i++)
		{
			fin[i]=false;
		}
		int check=0;
		int check1=0;
		do
		{
			for(int i=0;i<n;i++)
			{
				boolean flag=true;
				if(fin[i]==false)
				{
					for(int j=0;j<m;j++)
					{
						if(avail[j]<nee[i][j])
							flag=false;
					}
					if(flag)
					{
						for(int j=0;j<m;j++)
						{
							avail[j]+=allo[i][j];
						}
						safe[check]=i;
						check++;
						fin[i]=true;
					}
				}
			}
			check1++;
		}while(check<n&&check1<n);
		if(check>n)
		{
			return false;
		}
		else 
		{
			return true;
			
		}
	}
	static boolean requFreq(int a[],int al[][],int need[][],int req[],int n1,int m1,int pid)
	{
		int n=n1;
		int m=m1;
		int requested[]=new int[m];
		int allocated[][]=new int[n][m];
		int needed[][]=new int[n][m];
		int available[]=new int[m];
		int process=pid;
		for(int i=0;i<m;i++)
		{
			available[i]=a[i];
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				allocated[i][j]=al[i][j];
				
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<m;j++)
			{
				needed[i][j]=need[i][j];
				
			}
		}
		for(int i=0;i<m;i++)
		{
			requested[i]=req[i];
		}
		boolean flag = true;
		for(int i=0;i<m;i++)
		{
			if(needed[process][i]<requested[i])
			{
				flag=false;
			}
		}
		if(flag)
		{
			for(int i=0;i<m;i++)
			{
				if(available[i]<requested[i])
				{
					flag=false;
				}
			}
			if(flag)
			{
				for(int i=0;i<m;i++)
				{
					needed[process][i]=needed[process][i]-requested[i];
					allocated[process][i]=allocated[process][i]+requested[i];
					available[i]=available[i]-requested[i];
				}
				if(safety(available,allocated,need,n,m))
					return true;
				else
					System.out.println("leads to deadlock");
			}
			else
			{
				System.out.println("wait");
			}
		}
		else
			System.out.println("Exceeding limit");
		return false;
	}
}
