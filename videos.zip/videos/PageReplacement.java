package practice;

import java.io.*;
import java.util.*;

public class PageReplacement 
{
		Scanner s=new Scanner(System.in);
		int f,page=0,ch,pgf=0,n,chn=0,pgh=0;
		boolean flag;
		int pages[],ab; 
		int frames, pointer = 0, hit = 0, fault = 0,ref_len;
        boolean isFull = false;
        int buffer[];
        int reference[];
        int mem_layout[][];
        
	public void fifo() throws NumberFormatException, IOException
	{		
		int pt=0;
		System.out.println("enter no. of frames: ");
		f=s.nextInt();
		int frame[]=new int[f];
		for(int i=0;i<f;i++)
		{
				frame[i]=-1;
		}
		System.out.println("enter the no of pages ");
		n=s.nextInt();
		pages=new int[n];
		System.out.println("enter the page no ");
		for(int j=0;j<n;j++)
		pages[j]=s.nextInt();
		do
		{
		int pg=0;
		for(pg=0;pg<n;pg++)
		{
			page=pages[pg];
			flag=true;
			for(int j=0;j<f;j++)
			{
				if(page==frame[j])
				{
					flag=false;
					break;
				}
			}
			if(flag)
			{
				frame[pt]=page;
				pt++;
				if(pt==f)
				pt=0;
				System.out.print("frame :");
				for(int j=0;j<f;j++)
				System.out.print(frame[j]+"   ");
				System.out.println();
				pgf++;
			}
			else
			{
				System.out.print("frame :");
				for(int j=0;j<f;j++)
				System.out.print(frame[j]+"  ");
				System.out.println();
				pgh++;
			}
			chn++;
		}
		}while(chn!=n);
		System.out.println("Page fault:"+pgf);
		System.out.println("Page hit:"+pgh);
		
	}
	
	public void lru() throws NumberFormatException, IOException 
	{
		int k=0;
		System.out.println("enter no. of frames: ");
		f=s.nextInt();
		int frame1[]=new int[f];
		int a[]=new int[f];
		int b[]=new int[f];
		for(int i=0;i<f;i++)
		{
			frame1[i]=-1;
			a[i]=-1;
			b[i]=-1;
		}
		System.out.println("enter the no of pages ");
		n=s.nextInt();
		pages=new int[n];
		System.out.println("enter the page no ");
		for(int j=0;j<n;j++)
		pages[j]=s.nextInt();
		do
		{
			int pg=0;
			for(pg=0;pg<n;pg++)
			{
				page=pages[pg];
				flag=true;
				for(int j=0;j<f;j++)
				{
						if(page==frame1[j])
						{
							flag=false;
							break;
						}
				}
			
				for(int j=0;j<f && flag;j++)
				{
					if(frame1[j]==a[f-1])
					{
						k=j;
						break;
					 }
				}
			
				if(flag)
				{
					frame1[k]=page;
					System.out.print("frame :" );
					for(int j=0;j<f;j++)
					System.out.print(frame1[j]+"  ");
					pgf++;
					System.out.println();
				}
				else
				{
					System.out.print("frame :" );
					for(int j=0;j<f;j++)
					System.out.print(frame1[j]+"  ");
					pgh++;
					System.out.println();
				}
				int p=1;
				b[0]=page;
				for(int j=0;j<a.length;j++)
				{
					if(page!=a[j] && p<f)
					{
						b[p]=a[j];
					 	p++;
					}
				}
				for(int j=0;j<f;j++)
				{
					a[j]=b[j];
				}
				chn++;
				}
			}while(chn!=n);
	System.out.println("Page fault:"+pgf);
	System.out.println("Page Hit:"+pgh);
    }
	
	public void optimal()throws NumberFormatException, IOException
	{
			System.out.println("Enter the number of Frames : ");
	        f = s.nextInt();
	        System.out.println("Enter number of pages : ");
	        int n = s.nextInt();
	        pages = new int[n];
	        mem_layout = new int[n][f];
	        int[] frame = new int[f];
	        for(int j = 0; j < f; j++)
	                frame[j] = -1;
	        
	        System.out.println("Enter page number: ");
	        for(int i = 0; i < n; i++)
	        {
	            pages[i] = s.nextInt();
	        }
	        System.out.println();
	        
	        for(int i = 0; i < n; i++)
	        {
	        	int search = -1;
	        	for(int j = 0; j < f; j++)
	        	{
	        		if(frame[j] == pages[i])
	        		{
	        			search = j;
	        			hit++;
	        			break;
	        		} 
	        	}
	         if(search == -1)
	         {
	          if(isFull)
	          {
	           int index[] = new int[f];
	           boolean index_flag[] = new boolean[f];
	           for(int j = i + 1; j < n; j++)
	           {
	            for(int k = 0; k < f; k++)
	            {
	             if((pages[j] == frame[k]) && (index_flag[k] == false))
	             {
	              index[k] = j;
	              index_flag[k] = true;
	              break;
	             }
	            }
	           }
	           int max = index[0];
	           pointer = 0;
	           if(max == 0)
	            max = 200;
	           for(int j = 0; j < f; j++)
	           {
	            if(index[j] == 0)
	             index[j] = 200;
	            if(index[j] > max)
	            {
	             max = index[j];
	             pointer = j;
	            }
	           }
	          }	//isfull close
	          frame[pointer] = pages[i];
	          fault++;
	          if(!isFull)
	          {
	           pointer++;
	              if(pointer == f)
	              {
	               pointer = 0;
	               isFull = true;
	              }
	          }
	         }	// if search=-1 close
	            for(int j = 0; j < f; j++)
	                mem_layout[i][j] = frame[j];
	        }	// main i close
	        
	        for(int i = 0; i < f; i++)
	        {
	            for(int j = 0; j < n; j++)
	            	//
	                System.out.printf("%3d ",mem_layout[j][i]);
	            System.out.println();
	        }
	        
	        System.out.println("The number of Hits: " + hit);
	        System.out.println("The number of Faults: " + fault);
	}
    	
	public static void main(String[] args) throws NumberFormatException, IOException {
		Scanner sc=new Scanner(System.in);
		do{
		int choice;
		PageReplacement pg=new PageReplacement();
		System.out.println("Enter the choice\n1.FIFO\n2.LRU\n3.Optimal");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1:pg.fifo();
		break;
		case 2:pg.lru();//only for integer
		break;
		case 3:pg.optimal();
		break;
		}
		System.out.println("Continue(1/0)?");
		}while(sc.nextInt()==1);
	}	
}

/* Output :
Enter the choice
1.FIFO
2.LRU
3.Optimal
3
Enter the number of Frames : 
3
Enter number of pages : 
10
Enter page number: 
2
3
4
2
1
3
7
5
4
3

  2   2   2   2   1   1   7   5   5   5 
 -1   3   3   3   3   3   3   3   3   3 
 -1  -1   4   4   4   4   4   4   4   4 
The number of Hits: 4
The number of Faults: 6
Continue(1/0)?
1
Enter the choice
1.FIFO
2.LRU
3.Optimal
1
enter no. of frames: 
3
enter the no of pages 
14
enter the page no 
4
7
3
0
1
7
3
8
5
4
5
3
4
7
frame :4   -1   -1   
frame :4   7   -1   
frame :4   7   3   
frame :0   7   3   
frame :0   1   3   
frame :0   1   7   
frame :3   1   7   
frame :3   8   7   
frame :3   8   5   
frame :4   8   5   
frame :4  8  5  
frame :4   3   5   
frame :4  3  5  
frame :4   3   7   
Page fault:12
Page hit:2
Continue(1/0)?
1
Enter the choice
1.FIFO
2.LRU
3.Optimal
2
enter no. of frames: 
3
enter the no of pages 
15
enter the page no 
7
0
1
2
0
3
0
4
2
3
0
3
2
1
2
frame :7  -1  -1  
frame :7  0  -1  
frame :7  0  1  
frame :2  0  1  
frame :2  0  1  
frame :2  0  3  
frame :2  0  3  
frame :4  0  3  
frame :4  0  2  
frame :4  3  2  
frame :0  3  2  
frame :0  3  2  
frame :0  3  2  
frame :1  3  2  
frame :1  3  2  
Page fault:10
Page Hit:5
Continue(1/0)?


 */
 
