package practice;

import java.io.*;
import java.util.*;

public class RR1 
{
	public static void main(String[] args)throws IOException
	{
		Scanner s=new Scanner(System.in);
		int i,j,k,q,sum=0;
		System.out.println("Enter the no of processes :");
		int n=s.nextInt();
		int bt[]=new int[n];
		int wt[]=new int[n];
		int a[]=new int[n];
		int tat[]=new int[n];
		System.out.println("Enter the CPU burst time :");
		for(i=0;i<n;i++)
		{
			System.out.println("Enter the burst time for process"+(i+1));
			bt[i]=s.nextInt();
		}
		System.out.println("Enter the time quantum :");
		q=s.nextInt();
		for(i=0;i<n;i++)
			a[i]=bt[i];
		for(i=0;i<n;i++)
			wt[i]=0;
		do
		{
			for(i=0;i<n;i++)
			{
				if(bt[i]>q)
				{
					bt[i]-=q;
					for(j=0;j<n;j++)
					{
						if((j!=i)&&(bt[j]!=0))
							wt[j]+=q;
					}
				}
				else {
					for(j=0;j<n;j++)
					{
						if((j!=i)&&(bt[j]!=0))
							wt[j]+=bt[i];
					}
					bt[i]=0;
				}
			}
			sum=0;
			for(k=0;k<n;k++)
				sum=sum+bt[k];
		}while(sum!=0);
		
		for(i=0;i<n;i++)
			tat[i]=wt[i]+a[i];
		System.out.println("Process\tBurst Time\tCompletion Time\tWaiting Time");
		for(i=0;i<n;i++)
		System.out.println("Process"+(i+1)+"\t\t"+a[i]+"\t\t"+tat[i]+"\t\t"+wt[i]);
		float avgwaitingtime=0;
		float avgturnaroundtime=0;
		for(j=0;j<n;j++)
		{
			avgwaitingtime+=wt[j];
		}
			for(j=0;j<n;j++){
			avgturnaroundtime+=tat[j];
			}
		System.out.println("Average Waiting Time :"+avgwaitingtime/n);
		System.out.println("Average Turnaround Time :"+avgturnaroundtime/n);
	}
}

/* Output :
Enter the no of processes :
3
Enter the CPU burst time :
Enter the burst time for process1
24
Enter the burst time for process2
3
Enter the burst time for process3
3
Enter the time quantum :
4
Process	Burst Time	Completion Time	Waiting Time
Process1		24		30		6
Process2		3		7		4
Process3		3		10		7
Average Waiting Time :5.6666665
Average Turnaround Time :15.666667
*/