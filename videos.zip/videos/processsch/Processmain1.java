package practice;

import java.util.*;

class fcfs
{
	int submission;
	int bursts;
	int completiontime=0;
	int waiting;
	int turnaround;
	fcfs(int sub,int bur)
	{
		submission=sub;
		bursts=bur;
	}
}

public class Processmain1 
{
	private static Scanner s;
	static int avgwaitingtime=0;
	static int avgcompletiontime=0;
	public static void main(String[] args)
	{
		s=new Scanner(System.in);
		int x=0;
		System.out.println("Enter the no. of processes :");
		int n=s.nextInt();
		fcfs[] myprocess=new fcfs[n];
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the arrival time and CPU burst : ");
			int sub=s.nextInt();
			int bur=s.nextInt();
			myprocess[i]=new fcfs(sub,bur);
		}
		for(int i=0;i<myprocess.length;i++)
		{
			x = x + myprocess[i].bursts;
			myprocess[i].completiontime = x;
			myprocess[i].turnaround = myprocess[i].completiontime - myprocess[i].submission;
			myprocess[i].waiting = myprocess[i].turnaround - myprocess[i].bursts;
			System.out.println("Process"+i+":");
			System.out.println("TurnaroundTime\tCompletionTime\tWaitingTime");
			System.out.println(myprocess[i].turnaround+"\t\t"+myprocess[i].completiontime+"\t\t"+myprocess[i].waiting);
			avgwaitingtime = avgwaitingtime + myprocess[i].waiting;
			avgcompletiontime = avgcompletiontime + myprocess[i].completiontime;
		}
		System.out.println("Average Waiting Time :"+avgwaitingtime/myprocess.length);
		System.out.println("Average Completion Time :"+avgcompletiontime/myprocess.length);
	}
}

/* Output :
Enter the no. of processes :
3
Enter the arrival time and CPU burst : 
0 24
Enter the arrival time and CPU burst : 
0 3
Enter the arrival time and CPU burst : 
0 3
Process0:
TurnaroundTime	CompletionTime	WaitingTime
24		24		0
Process1:
TurnaroundTime	CompletionTime	WaitingTime
27		27		24
Process2:
TurnaroundTime	CompletionTime	WaitingTime
30		30		27
Average Waiting Time :17
Average Completion Time :27
*/