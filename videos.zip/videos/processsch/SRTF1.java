package practice;

import java.util.*;
import java.io.*;

public class SRTF1 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the no of procsses :");
		int n=s.nextInt();
		int pid[]=new int[n];
		int at[]=new int[n];
		int bt[]=new int[n];
		int ct[]=new int[n];
		int wt[]=new int[n];
		int ta[]=new int[n];
		int k[]=new int[n];
		int f[]=new int[n];
		int st=0,tot=0,i;
		float avgwt=0,avgta=0;
		
		for(i=0;i<n;i++)
		{
			pid[i]=i+1;
			System.out.println("Enter the arrival time for process "+(i+1));
			at[i]=s.nextInt();
			System.out.println("Enter the burst time for process "+(i+1));
			bt[i]=s.nextInt();
			k[i]=bt[i];
			f[i]=0;
		}
		
		while(true)
		{
			int c=n,min=999;
			if(tot==n)
				break;
			
			for(i=0;i<n;i++)
			{
				if((at[i]<=st)&&(f[i]==0)&&(bt[i]<min))
				{
					min=bt[i];
					c=i;
				}
			}
			
			if(c==n)
				st++;
			
			else
			{
				bt[c]--;
				st++;
				if(bt[c]==0)
				{
					ct[c]=st;
					f[c]=1;
					tot++;
				}
			}
		}
		
		for(i=0;i<n;i++)
		{
			ta[i]=ct[i]-at[i];
			wt[i]=ta[i]-k[i];
			avgwt+=wt[i];
			avgta+=ta[i];
		}
		
		System.out.println("Process\tArrival Time\tBurst Time\tTurnaround Time\tCompletion Time\tWaiting Time");
		for(i=0;i<n;i++)
		{
			System.out.println(pid[i]+"\t\t"+at[i]+"\t\t"+k[i]+"\t\t"+ta[i]+"\t\t"+ct[i]+"\t\t"+wt[i]+"\t\t");
		}
		
		System.out.println("Average Turnaround Time :"+(avgta/n));
		System.out.println("Average Waiting Time :"+(avgwt/n));
	}
}

/* Output :
Enter the no of procsses :
5
Enter the arrival time for process 1
0
Enter the burst time for process 1
10
Enter the arrival time for process 2
2
Enter the burst time for process 2
1
Enter the arrival time for process 3
4
Enter the burst time for process 3
2
Enter the arrival time for process 4
8
Enter the burst time for process 4
4
Enter the arrival time for process 5
12
Enter the burst time for process 5
3
Process	Arrival Time	Burst Time	Turnaround Time	Completion Time	Waiting Time
1		0		10		20		20		10		
2		2		1		1		3		0		
3		4		2		2		6		0		
4		8		4		4		12		0		
5		12		3		3		15		0		
Average Turnaround Time :6.0
Average Waiting Time :2.0
*/