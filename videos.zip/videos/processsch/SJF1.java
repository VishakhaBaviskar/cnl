package practice;

import java.io.*;
import java.util.*;

public class SJF1 
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the no of processes :");
		int n=s.nextInt();
		int at[]=new int[n];
		int bt[]=new int[n];
		int ct[]=new int[n];
		int ta[]=new int[n];
		int wt[]=new int[n];
		int f[]=new int[n];
		int pid[]=new int[n];
		float totct=0;
		int st=0,tot=0;
		float avgwt=0;
		float avgta=0;
		
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter the arrival time of process"+(i+1));
			at[i]=s.nextInt();
			System.out.println("Enter the burst time pf process"+(i+1));
			bt[i]=s.nextInt();
			totct += bt[i];
			pid[i]=i+1;
			f[i]=0;
		}
		
		boolean a=true;
		while(true)
		{
			int c=n,min=999;
			if(tot==n)
				break;
			
			for(int i=0;i<n;i++)
			{
				if((at[i]<=st)&&(f[i]==0)&&(bt[i]<min))
				{
					min=bt[i];
					c=i;
				}
			}
			if(c==n)
				st++;
			else
			{
				ct[c]=st+bt[c];
				st+=bt[c];
				ta[c]=ct[c]-at[c];
				wt[c]=ta[c]-bt[c];
				f[c]=1;
				tot++;
			}
		}
		System.out.println("Process\tArrival Time\tBurst Time\tCompletio Time\tWaiting Time\tTurnaround Time");
		for(int i=0;i<n;i++)
		{
			avgwt+=wt[i];
			avgta+=ta[i];
			System.out.println(pid[i]+"\t\t"+at[i]+"\t\t"+bt[i]+"\t\t"+ct[i]+"\t\t"+wt[i]+"\t\t"+ta[i]);
		}
		System.out.println("Average Waiting Time :"+(avgwt/n));
		System.out.println("Average Turnaround Time :"+(avgta/n));
		System.out.println("Throughput :"+(n/totct));
	}
}

/* Output :
Enter the no of processes :
5
Enter the arrival time of process1
0
Enter the burst time pf process1
10
Enter the arrival time of process2
2
Enter the burst time pf process2
1
Enter the arrival time of process3
4
Enter the burst time pf process3
2
Enter the arrival time of process4
8
Enter the burst time pf process4
4
Enter the arrival time of process5
12
Enter the burst time pf process5
3
Process	Arrival Time	Burst Time	Completio Time	Waiting Time	Turnaround Time
1		0		10		10		0		10
2		2		1		11		8		9
3		4		2		13		7		9
4		8		4		20		8		12
5		12		3		16		1		4
Average Waiting Time :4.8
Average Turnaround Time :8.8
Throughput :0.25
*/