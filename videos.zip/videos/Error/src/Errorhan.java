import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;
class mne
{
	public String mn;
int op;
int len;
	mne()
	{
		mn=" ";
		op=99;
		len=0;
	}

}
class SymTuple {
String symbol;
int value,no;

SymTuple(int n,String s1, int i1) {
	no=n;
	symbol = s1;
	value = i1;
	
	
}
}

public class Errorhan {
	ArrayList<SymTuple> symbol=new ArrayList<>();
	ArrayList<String>nsym =new ArrayList<>();
	 File file = new File("error.txt");
	 int lc=1,s=1;
	mne mno[]=new mne[10];


	void mnet()
	{
		for(int i=0;i<10;i++)
		{
		mno[i]=new mne();
		}
	   mno[0].mn="ADD";
	   mno[0].op=1;
	   mno[0].len=3;
	   
	   mno[1].mn="MOVER";
	   mno[1].op=4;
	   mno[1].len=3;
	   
	   mno[2].mn="MOVEM";
	   mno[2].op=5;
	   mno[2].len=3;
	   
	   mno[3].mn="sub";
	   mno[3].op=2;
	   mno[3].len=3;
	   
	   mno[4].mn="MULT";
	   mno[4].op=3;
	   mno[4].len=3;

	   mno[5].mn="BC";
	   mno[5].op=7;
	   mno[5].len=3;
	   
	}  
	
	void errhan()
	{
		mnet();
		BufferedReader br = null;
		
        FileReader fr = null;
		StringTokenizer st1=null,st2=null;
		try{
			
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			int flag=0,en=0;
			String sCline,fline;
			String tok="";
			fline=br.readLine();
			st1=new StringTokenizer(fline," ");
			if(st1.nextToken().equals("START"))
		    {
				en=0;
		    
			}
			while ((sCline = br.readLine()) != null) 
			{
				st1 =new StringTokenizer(sCline," ");
				String s_arr[] = new String[st1.countTokens()];
				int j=0;
				lc++;
				for(int i=0 ; i < s_arr.length ; i++) {
					
					tok = st1.nextToken();
					
						if(tok.equals(";"))
						{
							break;
						}
						s_arr[j]=tok;
						j++;
					
				}
				//--------------------------------------------------
				int i=0;
				while (i<j)
		        { tok=s_arr[i];
		        	flag=0;
		        for(int k=0;k<6;k++)
	        	{
	        		
	        	if(tok.equalsIgnoreCase(mno[k].mn))
	        	{
	        		if(i+1<j&&s_arr[i+1].equals(":"))
	        		{
	        			System.out.println("Mnemonic used as label or symbol at line "+lc);
	        		}else if(j<i+3)
	        		{
	        			System.out.println("Incomplete insructions at line "+lc);
	        		}
	        		flag=1;
	        		
	        	}
	        	}
		        if(tok.equals("END"))
		        {
		        	en=1;
		        	flag=1;
		        }else if(i+1<j &&flag==0 &&s_arr[i+1].equals(":"))
		        {
		        	for(SymTuple in2 : symbol)
    				{
    					if(tok.equals(in2.symbol))
    					{
    						if(in2.value==0)
    						   in2.value=lc;
    						else
    							System.out.println("Duplicate defination of symbol "+tok+" at line no  "+lc);
    					
    					}
    				} 
			        
			     
		          
			      flag=1;
		        
		        }else if(tok.equals(":")||tok.equals(",")||tok.equals("AREG")||tok.equals("BREG")||tok.equals("CREG")||tok.equals("DREG")||tok.equals("STOP"))
		      {
		    	  flag=1;
		      }else if(i+2<j && s_arr[i+2].equals(",")&& flag==0)
		      {
		    	  System.out.println("mnemonic "+s_arr[i]+" not recognised at line "+lc);
		    	  flag=1;
		      }else  if(flag==0 && !tok.contains("="))
		      {
		    	 symbol.add(new SymTuple(s,tok,0));
		    	 s++;
		       }
			
		         i++;
		        }
			}
			if(en==0)
			{
				System.out.println("The code doesn't contain end");
			}
			for(SymTuple in2 : symbol)
			{
				if(in2.value==0)
				{
					System.out.println("Undefined symbol or label "+in2.symbol);
				}
			}
			 //--------------------------------------------------------------------
		     
		      
		}catch(Exception e)
		{
			e.printStackTrace();
		}
			
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Errorhan ob=new Errorhan();
		ob.errhan();

	}

}
